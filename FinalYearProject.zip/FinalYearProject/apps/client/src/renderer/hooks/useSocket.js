import { useEffect, useState, useRef } from 'react';
import io from 'socket.io-client';

let socketInstance = null;
let isInitialized = false;

export function useSocket() {
  const [socket, setSocket] = useState(() => {
    // Initialize socket immediately in state initializer
    if (!socketInstance && !isInitialized) {
      isInitialized = true;
      
      // Get user data from sessionStorage for socket handshake
      const userJson = sessionStorage.getItem('user');
      const token = sessionStorage.getItem('token');
      const user = userJson ? JSON.parse(userJson) : null;
      
      socketInstance = io('http://localhost:5000', {
        reconnection: true,
        reconnectionDelay: 1000,
        reconnectionDelayMax: 5000,
        reconnectionAttempts: 5,
        auth: {
          token: token,
          userId: user?.id || user?._id,
          userName: user?.name,
          userEmail: user?.email
        }
      });
      console.log('[useSocket] Socket instance created:', socketInstance.id, 'User:', user?.name);
    }
    return socketInstance;
  });

  useEffect(() => {
    // Ensure socket is set
    if (socketInstance) {
      setSocket(socketInstance);
    }

    // Handle reconnection
    const handleReconnect = () => {
      console.log('[useSocket] Socket reconnected with ID:', socketInstance.id);
      setSocket(socketInstance);
    };

    if (socketInstance) {
      socketInstance.on('connect', handleReconnect);
    }

    return () => {
      if (socketInstance) {
        socketInstance.off('connect', handleReconnect);
      }
    };
  }, []);

  return { socket };
}

// Helper function to disconnect and reset socket (called on logout)
export function disconnectSocket() {
  if (socketInstance) {
    console.log('[useSocket] Disconnecting socket:', socketInstance.id);
    socketInstance.disconnect();
    socketInstance = null;
    isInitialized = false;
  }
}
